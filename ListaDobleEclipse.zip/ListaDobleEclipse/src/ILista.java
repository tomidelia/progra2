public interface ILista {
    void inicializar();
    void agregar(int valor);
    void eliminar(int valor);
    void imprimirDesdeInicio();
    void imprimirDesdeFin();
}